# Python scripts

Little random scripts that interact with the site

Before running any of these, make sure you have the proper modules installed:

```shell
$ pip install bs4 requests
```

# Descriptions

### asciiFarter.py

Farts out the newest ascii art this site has to offer when run.

### status.py

Prints all the crawlable IDs and their values from https://yeetssite.github.io/Python/status.html

This is more of a template script, but can still be useful on its own.


